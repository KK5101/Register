import React from "react";
import { useFormik } from "formik";
import "./Formik.css";

const BasicForm = () => {
  const formik = useFormik({
    initialValues: {
      FullName: "",
      Username: "",
      email: "",
      password: "",
      ConfirmPassword: "",
      terms: false,
    },
    onSubmit: (values) => {
      alert(JSON.stringify(values, null, 2));
    },
  });

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="table-container">
        <h1>Registration Details</h1>
        <div>
          <label>Full Name </label>
          <input
            type="fullname"
            name="fullname"
            value={formik.values.fullname}
            onChange={formik.handleChange}
          />
        </div>
        <div>
          <label>Username</label>
          <input
            type="username"
            name="username"
            value={formik.values.username}
            onChange={formik.handleChange}
          />
        </div>
        <div>
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={formik.values.email}
            onChange={formik.handleChange}
          />
        </div>

        <div>
          <label>Password</label>
          <input
            type="password"
            name="password"
            value={formik.values.password}
            onChange={formik.handleChange}
          />
        </div>
        <div>
          <label>Confirm Password</label>
          <input
            type="confirm password"
            name="Confirm password"
            value={formik.values.confirmpassword}
            onChange={formik.handleChange}
          />
        </div>
        <label>
          <input type="checkbox" name="terms" />* I have read and agree to the
          Terms
        </label>
        <span>
          <button type="reset">Reset</button>
          <button type="submit">Submit</button>
        </span>
      </div>
    </form>
  );
};

export default BasicForm;
